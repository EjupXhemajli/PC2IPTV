using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace EXIPTV;

/// <summary>Leerer String -> Collapsed, sonst Visible (für die Fehlerzeile).</summary>
public class EmptyToCollapsedConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        => string.IsNullOrWhiteSpace(value as string) ? Visibility.Collapsed : Visibility.Visible;

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
